from django.shortcuts import render
from django.http import HttpResponse

# Create your views here.

def views(request):
    return HttpResponse("<h1>This is an H1 heading boy</h1>")