from django import forms

class MyForm(forms.Form):
    FirstName = forms.CharField(max_length=200)
    LastName = forms.CharField(max_length=200)
    Email = forms.EmailField(max_length=200)
    Birthday = forms.DateField()