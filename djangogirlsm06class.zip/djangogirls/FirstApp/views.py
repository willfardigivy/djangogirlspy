from django.shortcuts import render
from django.http import HttpResponse

# Create your views here.

def splash(request):
    myDic = {
        'spley':'Sign in with your user credentials:',
        'keyey':'William Fardig Website Boy',
        'ivyintro':'Welcome to Ivy Tech Community College'
        }
    return render(request, 'index.html', context = myDic)